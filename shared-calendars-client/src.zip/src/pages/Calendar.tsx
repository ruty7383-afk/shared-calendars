import { getEvents } from "../services/authServices";
import { useLocation, useNavigate, useParams } from "react-router-dom"
import { useState } from "react"
import type { EventExist } from "../types/event"
import { HDate, gematriya } from "@hebcal/hdate"
import { useQuery } from "@tanstack/react-query"
import { getErrorMessege } from "../utils/getErrorMessege";
import CreateEvent from "../components/events/CreateEvent";
import DeleteEvent from "../components/events/DeleteEvent";
import UpdateEvent from "../components/events/UpdateEvent";
import { useAuthContext } from "../context/AuthContext";
import ShowEventt from "../components/events/ShowEvent"
import CalendarHeader from "../components/calendars/CalendarHeader";
import { show } from "../utils/showEv";
import CalendarDay from "../components/calendars/CalendarDay";
import CalendarWeek from "../components/calendars/CalendarWeek";

const today = new HDate(new Date())
const Calendar = () => {
    const { id } = useParams()
    const [showCreateEvent, setShowCreateEvent] = useState(false)
    const [showCreateEventOn, setShowCreateEventOn] = useState(false)
    const navigate = useNavigate()
    const { user } = useAuthContext()
    const [eventToUpdate, setEventToUpdate] = useState<EventExist | null>(null)
    const [selectedDay, setSelectedDay] = useState<number>()
    const [openImagesDay, setOpenImagesDay] = useState<number | null>(null)
    const [openEventsDay, setOpenEventsDay] = useState<number | null>(null)
    const location = useLocation()
    const calendar = location.state?.calendar
    const [nowMonth, setNowMonth] = useState<number>(today.getMonth())
    const [nowYear, setNowYear] = useState<number>(today.getFullYear())
  type CalendarView = "month" | "week" | "day"

const [view, setView] = useState<CalendarView>("month")
const [selectedViewDay, setSelectedViewDay] = useState<number>(today.getDate())
    const { data: events = [], isLoading: isLoadingEvents, isError: isErrorEvents, error: errorEvents } = useQuery<EventExist[]>({
        queryKey: ["events", id, nowYear, nowMonth],

        queryFn: async () => {
            const response = await getEvents(
                Number(id),
                nowYear,
                nowMonth
            )

            return response.data
        },

        enabled: id != null
    })

    interface Day {
        dayNumber: number
        events: EventExist[]

    }
    const daysInMonth = HDate.daysInMonth(nowMonth, nowYear)
    const days: Day[] = Array.from(
        { length: daysInMonth },
        (_, index) => ({
            dayNumber: index + 1,
            events: [],
            notes: []

        })
    )
    //הכנסת ארועים למערך הימים
    events.map((e) => {
        if (e.hebrewDay === 30 && daysInMonth < 30) {
            days[e.hebrewDay - 2].events.push(e)
        }
        else {
            days[e.hebrewDay - 1].events.push(e)

        }
    })



    const moveView = (direction: 1 | -1) => {

    if (view === "month") {
        const current = new HDate(1, nowMonth, nowYear)

        const newDate =
            direction === 1
                ? current.add(1, "month")
                : current.subtract(1, "month")

        setNowMonth(newDate.getMonth())
        setNowYear(newDate.getFullYear())
        setSelectedViewDay(1)

        return
    }

    const current = new HDate(
        selectedViewDay,
        nowMonth,
        nowYear
    )

    const amount = view === "week" ? 7 : 1

    const newDate =
        direction === 1
            ? current.add(amount, "day")
            : current.subtract(amount, "day")

    setSelectedViewDay(newDate.getDate())
    setNowMonth(newDate.getMonth())
    setNowYear(newDate.getFullYear())
}

const nextMonth = () => moveView(1)
const prevMonth = () => moveView(-1)


   
    if (!calendar) {
        return <p>לא נמצאו פרטי הלוח</p>
    }
    //כדי שרק שאין דברים על הלוח יציג
    if (isLoadingEvents) {
        return <p>טוען...</p>
    }
    //שיציג אם החודש מתחיל ביום שלישי רק אז א
    const firstDayOfMonth = new HDate(1, nowMonth, nowYear).getDay()

    const weekDays = [
        "ראשון",
        "שני",
        "שלישי",
        "רביעי",
        "חמישי",
        "שישי",
        "שבת"
    ]
    const openedImages =
        openImagesDay !== null
            ? days[openImagesDay - 1]?.events.filter(
                event => event.hasImage && event.imageUrl
            ) ?? []
            : []
            const weeksInMonth = Math.ceil(
    (firstDayOfMonth + daysInMonth) / 7
)
    return (
<div
    dir="rtl"
    className="
        flex h-[calc(100dvh-64px)]
        w-full flex-col
        overflow-hidden
        bg-gradient-to-b
        from-emerald-50/40
        via-white
        to-emerald-50/50
    "
>
 <CalendarHeader
    calendar={calendar}
    nowMonth={nowMonth}
    nowYear={nowYear}
    prevMonth={prevMonth}
    nextMonth={nextMonth}
    setShowCreateEvent={setShowCreateEvent}
    navigate={navigate}
    view={view}
    setView={setView}
/>    

{view === "month" && (
   <div
    dir="rtl"
    className="flex min-h-0 w-full flex-1 flex-col overflow-hidden"
>
                <div className="flex min-h-0 flex-1 flex-col overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">

                    {/* שמות הימים */}
                    <div className="grid grid-cols-7 bg-slate-50">

                        {weekDays.map((weekDay) => (
                            <div
                                key={weekDay}
                                className="border-l border-slate-200 py-1.5 text-center text-sm font-semibold text-slate-500 last:border-l-0"
                            >
                                {weekDay}
                            </div>
                        ))}

                    </div>


                    {/* התאריכים */}
<div
    className="grid min-h-0 flex-1 grid-cols-7"
    style={{
        gridTemplateRows: `repeat(${weeksInMonth}, minmax(0, 1fr))`
    }}
>                        {/* מקומות ריקים לפני א' בחודש */}
                        {Array.from({ length: firstDayOfMonth }).map((_, index) => (
                            <div
                                key={`empty-${index}`}
className="min-h-0 border-l border-t border-slate-200 bg-slate-50/60"                            />
                        ))}


                        {days.map((day) => {

                            const images = day.events.filter(
                                event => event.hasImage && event.imageUrl
                            )

                            const visibleEvents = day.events.slice(0, 4)

                            const isToday =
                                day.dayNumber === today.getDate() &&
                                nowMonth === today.getMonth() &&
                                nowYear === today.getFullYear()

                            return (

                                <div
                                    key={day.dayNumber}
                                    className={`group 
relative h-full min-h-0                            overflow-hidden
                            border-l border-t border-slate-200
                            bg-white
                            transition
                            hover:z-10 hover:shadow-lg
                            ${isToday ? "ring-2 ring-inset ring-violet-500" : ""}
                        `}

                                ><div className="absolute bottom-2 left-2 z-30 flex items-center gap-1.5">

                                        {images.length > 2 && (
                                            <button
                                                type="button"
                                                dir="ltr"
                                                onClick={(e) => {
                                                    e.stopPropagation()
                                                    setOpenImagesDay(day.dayNumber)
                                                }}
                                                className="
                flex h-7 w-9
                items-center justify-center
                rounded-full
                bg-white/60
                text-[10px] font-semibold
                text-slate-500
                shadow-sm
                backdrop-blur-sm
                transition
                hover:bg-white/90
                hover:text-violet-600
            "
                                            >
                                                <span className="relative inline-flex h-7 w-7 items-center justify-center">
    <span className="text-xl">
        📷
    </span>

    <span
        className="
            absolute
            inset-0
            flex items-center justify-center
            text-[9px]
            font-bold
            text-slate-700
        "
    >
        +{images.length - 2}
    </span>
</span>
                                            </button>
                                        )}

                                        {day.events.length > 5 && (
                                            <button
                                                type="button"
                                                dir="ltr"
                                                onClick={(e) => {
                                                    e.stopPropagation()
                                                    setOpenEventsDay(day.dayNumber)
                                                }}
                                                className="
                flex h-7 w-9
                items-center justify-center
                rounded-full
                bg-white/60
                text-[10px] font-semibold
                text-slate-500
                shadow-sm
                backdrop-blur-sm
                transition
                hover:bg-white/90
                hover:text-violet-600
            "
                                            >
                                              <span className="relative inline-flex h-7 w-7 items-center justify-center">
    <span className="text-xl">
        📝
    </span>

    <span
        className="
            absolute
            inset-0
            flex items-center justify-center
            text-[9px]
            font-bold
            text-slate-700
        "
    >
        +{day.events.length - 4}
    </span>
</span>
                                            </button>
                                        )}

                                    </div>

                                    {/* תמונות כרקע של כל הריבוע */}
                                    {images.length > 0 && (

                                        <div className="absolute inset-0 z-0">

                                            {/* תמונה אחת */}
                                            {images.length === 1 && (

                                                <button
                                                    type="button"
                                                    onClick={() => setOpenImagesDay(day.dayNumber)}
                                                    className="h-full w-full"
                                                >
                                                    <img
                                                        src={images[0].imageUrl || ""}
                                                        alt={images[0].title}
                                                        className="h-full w-full object-cover"
                                                    />
                                                </button>

                                            )}


                                            {/* שתי תמונות ומעלה */}
                                            {images.length >= 2 && (

                                                <button
                                                    type="button"
                                                    onClick={() => setOpenImagesDay(day.dayNumber)}
                                                    className="flex h-full w-full"
                                                >
                                                    <img
                                                        src={images[0].imageUrl || ""}
                                                        alt={images[0].title}
                                                        className="h-full w-1/2 object-cover"
                                                    />

                                                    <img
                                                        src={images[1].imageUrl || ""}
                                                        alt={images[1].title}
                                                        className="h-full w-1/2 object-cover"
                                                    />
                                                </button>
                                            )}

                                        </div>

                                    )}


                                    {/* מספר היום */}
                                    <div
                                        className={`
                                absolute right-2 top-2 z-20
                                flex h-8 min-w-8 items-center justify-center
                                rounded-full px-2
                                text-sm font-bold shadow-sm
                                ${isToday
                                                ? "bg-violet-600 text-white"
                                                : "bg-white/90 text-slate-700 backdrop-blur-sm"
                                            }
                            `}
                                    >
                                        {gematriya(day.dayNumber)}
                                    </div>


                                    {/* + ליצירת אירוע בתאריך */}
                                    <button
                                        onClick={() => {
                                            setSelectedDay(day.dayNumber)
                                            setShowCreateEventOn(true)
                                        }}
                                        className="
                                absolute left-2 top-2 z-20
                                flex h-8 w-8 items-center justify-center
                                rounded-full
                                bg-white/90 text-lg text-violet-600
                                opacity-0 shadow-sm backdrop-blur-sm
                                transition
                                hover:bg-violet-600 hover:text-white
                                group-hover:opacity-100
                            "
                                    >
                                        +
                                    </button>


                                    {/* יותר משתי תמונות */}

                                    {/* האירועים */}
                                    {day.events.length > 0 && (

                                 <div
    className="
            pointer-events-none
   absolute bottom-0 left-0 right-0 z-10
        px-2 pb-2 pt-2
        hover:z-40
    "
>

                                            <div className="relative space-y-0.5">
                                                                                      
                                                      
{visibleEvents.map((event) => {
    const t = show(event,nowYear)

    return (
        <ShowEventt
            key={event.id}
            event={event}
            t={t}
            calendar={calendar}
            user={user}
            onEdit={(event) => setEventToUpdate(event)}
            
        />
    )
})}
  </div>




                                           

                                        </div>

                                    )}

                                </div>

                            )
                        })}

                    </div>

                </div>

            </div>
)}
    {view === "week" && (
    <CalendarWeek
        days={days}
        nowMonth={nowMonth}
        nowYear={nowYear}
        selectedDay={selectedViewDay}
        show={(event:EventExist) => show(event, nowYear)}
        calendar={calendar}
        user={user}
        onEdit={(event:EventExist) => setEventToUpdate(event)}
    />
)}

{view === "day" && (
    <CalendarDay
        day={days[selectedViewDay - 1]}
        show={(event:EventExist) => show(event, nowYear)}
        calendar={calendar}
        user={user}
        onEdit={(event:EventExist) => setEventToUpdate(event)}
    />
)}      
            {showCreateEvent && (

                <div
                    onClick={() => setShowCreateEvent(false)}
                    className="fixed inset-0 z-50 flex items-center justify-center bg-black/45 p-5 backdrop-blur-[2px]"
                >

                    <div
                        onClick={(e) => e.stopPropagation()}
                        className="relative max-h-[90vh] w-full max-w-xl overflow-y-auto rounded-3xl bg-white p-7 shadow-2xl"
                    >

                        <CreateEvent
                            calendarId={Number(id)}
                            onClose={() => setShowCreateEvent(false)}
                        />

                    </div>

                </div>

            )}
            {showCreateEventOn && (

                <div
                    onClick={() => setShowCreateEventOn(false)}
                    className="fixed inset-0 z-50 flex items-center justify-center bg-black/45 p-5 backdrop-blur-[2px]"
                >

                    <div
                        onClick={(e) => e.stopPropagation()}
                        className="relative max-h-[90vh] w-full max-w-xl overflow-y-auto rounded-3xl bg-white p-7 shadow-2xl"
                    >

                        <CreateEvent
                            calendarId={Number(id)}
                            onClose={() => setShowCreateEventOn(false)}
                            defaultDay={selectedDay}
                            defaultMonth={nowMonth}
                            defaultYear={nowYear}
                        />

                    </div>

                </div>

            )}
            {eventToUpdate && (
                <div
                    className="
            fixed inset-0 z-50
            flex items-center justify-center
            bg-black/45
            p-5
            backdrop-blur-[2px]
        "
                    onClick={() => setEventToUpdate(null)}
                >
                    <div
                        className="
                max-h-[90vh]
                w-full max-w-xl
                overflow-y-auto
                rounded-3xl
                bg-white
                p-7
                shadow-2xl
            "
                        onClick={(e) => e.stopPropagation()}
                    >
                        <UpdateEvent
                            eventId={eventToUpdate.id}
                            event={eventToUpdate}
                            onClose={() => setEventToUpdate(null)}
                        />
                    </div>
                </div>
            )}
            {openImagesDay !== null && (

                <div
                    onClick={() => setOpenImagesDay(null)}
                    className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-6 backdrop-blur-sm"
                >

                    {openedImages.length === 1 ? (

                        <div className="relative">
                            <button
                                onClick={() => setOpenImagesDay(null)}
                                className="
                absolute -left-3 -top-3 z-20
                flex h-10 w-10 items-center justify-center
                rounded-full bg-white
                text-xl text-slate-600
                shadow-lg
                hover:bg-slate-100
            "
                            >
                                ×
                            </button>

                            <img
                                src={openedImages[0].imageUrl || ""}
                                alt={openedImages[0].title}
                                className="
                max-h-[60vh]
                max-w-[50vw]
                rounded-2xl
                object-contain
                shadow-2xl
            "
                            />
                        </div>

                    ) : (

                        <div
                            className="
            relative max-h-[85vh]
            w-full max-w-4xl
            overflow-y-auto
            rounded-3xl
            bg-white p-6
            shadow-2xl
        "
                        >
                            <button
                                onClick={() => setOpenImagesDay(null)}
                                className="
                absolute left-4 top-4
                flex h-9 w-9 items-center justify-center
                rounded-full bg-slate-100
                text-xl text-slate-500
                hover:bg-slate-200
            "
                            >
                                ×
                            </button>

                            <div className="mb-5 text-right text-xl font-bold text-slate-800">
                                תמונות:        </div>

                            <div className="grid grid-cols-2 gap-3 md:grid-cols-3">

                                {openedImages.map(event => (
                                    <div
                                        key={event.id}
                                        className="
                        overflow-hidden
                        rounded-2xl
                        border border-slate-200
                        bg-white
                    "
                                    >
                                        <img
                                            src={event.imageUrl || ""}
                                            alt={event.title}
                                            className="aspect-square w-full object-cover"
                                        />

                                        <div className="p-3 text-right text-sm font-medium text-slate-700">
                                            {event.title}
                                        </div>
                                    </div>
                                ))}

                            </div>
                        </div>

                    )}

                </div>

            )}
            
            {openEventsDay !== null && (

                <div
                    onClick={() => setOpenEventsDay(null)}
                    className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-6 backdrop-blur-sm"
                >

                    <div
                        onClick={(e) => e.stopPropagation()}
                        className="relative max-h-[85vh] w-full max-w-lg overflow-y-auto rounded-3xl bg-white p-6 shadow-2xl"
                    >

                        <button
                            onClick={() => setOpenEventsDay(null)}
                            className="absolute left-4 top-4 flex h-9 w-9 items-center justify-center rounded-full bg-slate-100 text-xl text-slate-500 hover:bg-slate-200"
                        >
                            ×
                        </button>

                        <div className="mb-5 text-right text-xl font-bold text-slate-800">
                            כל האירועים
                        </div>

                        <div className="space-y-2">

                            {days[openEventsDay - 1]?.events.map(event => {

                                const t = show(event,nowYear)

                                return (

                                    <div
                                        key={event.id}
                                        className="flex items-center justify-between gap-3 rounded-xl border border-slate-200 p-3"
                                    >

                                        <div
                                            className="text-right text-sm font-medium"
                                           
                                        >
                                            {t.text}
                                        </div>

                                        {(event.createdById === user?.id ||
                                            (
                                                calendar.role === "owner" &&
                                                event.visibility === "shared"
                                            )) && (

                                                <div className="flex shrink-0 gap-2">
                                                    <button
                                                        type="button"
                                                        onClick={(e) => {
                                                            e.stopPropagation()
                                                            setEventToUpdate(event)
                                                        }}
                                                        className="
        flex h-7 w-7
        items-center justify-center
        rounded-md
        bg-violet-50
        text-sm
        transition
        hover:bg-violet-100
    "
                                                    >
                                                        🖊️
                                                    </button>

                                                    <DeleteEvent
                                                        eventId={event.id}
                                                    />
                                                </div>

                                            )}

                                    </div>

                                )
                            })}

                        </div>

                    </div>

                </div>

            )}
            {isErrorEvents && <p style={{ color: "red" }}>{getErrorMessege(errorEvents)}</p>}


       </div>
    )
}
export default Calendar